
#include <stdio.h>

int main()
{
    int r,area;
    printf("Enter the radius of the circle:");
    scanf("%d",&r);
    area=3.14*r*r;
    printf("Area of the circle is : %d",area);
    return 0;
}
